### How to run: 
1. Tương đương với việc bạn ấn vào: Go Live
2. Trỏ thẳng vào node 
```bash
node server.js
```


3. ```npm install``` để cài đặt các dependencies (nếu có).

```json:package.json
{
  "scripts": {
    "start": "node server.js"
  }
}
```

Run : 
```bash
npm start
```