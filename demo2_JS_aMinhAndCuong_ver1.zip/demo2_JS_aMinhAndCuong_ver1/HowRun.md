### How to run: 
Tương đương với việc bạn ấn vào: Go Live
```bash
node server.js
```
